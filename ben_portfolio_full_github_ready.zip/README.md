# Ben Campbell's Marketing Portfolio

Welcome to my marketing portfolio – where creativity meets chaos in the best possible way.

## 🔥 What’s Inside

- **Social Media Campaigns** that slap
- **Writing Samples** with real strategy
- **Videos** that convert and entertain
- **Contact Info** if you want to make magic happen

## 🚀 Live Version

Once uploaded to GitHub Pages, you can view the site at:

```
https://yourusername.github.io/ben-portfolio/
```

Replace `yourusername` with your GitHub handle.

---

📫 **Email me**: [hirebencampbell@gmail.com](mailto:hirebencampbell@gmail.com)  
🔗 **Connect with me**: [LinkedIn](https://www.linkedin.com/in/bencampbell8/)
